# Methodology

dsVertClient implements three distributed algorithms for vertically
partitioned data: MHE-CKKS correlation with threshold decryption,
spectral PCA from a distributed correlation matrix, and encrypted-label
Block Coordinate Descent with IRLS for generalized linear models. This
vignette describes the mathematical foundations of each algorithm, the
cryptographic protocol that protects individual-level data, and the
security guarantees that follow from the protocol design.

## Overview

| Method | Function | Purpose |
|----|----|----|
| MHE-CKKS Correlation | [`ds.vertCor()`](https://isglobal-brge.github.io/dsVertClient/reference/ds.vertCor.md) | Cross-server correlation via threshold encryption |
| Spectral PCA | [`ds.vertPCA()`](https://isglobal-brge.github.io/dsVertClient/reference/ds.vertPCA.md) | PCA from distributed correlation matrix |
| Encrypted-Label BCD-IRLS | [`ds.vertGLM()`](https://isglobal-brge.github.io/dsVertClient/reference/ds.vertGLM.md) | GLM with response on one server only |
| ECDH-PSI Alignment | [`ds.psiAlign()`](https://isglobal-brge.github.io/dsVertClient/reference/ds.psiAlign.md) | Privacy-preserving record linkage |

------------------------------------------------------------------------

## Multiparty Homomorphic Encryption for Correlation

### CKKS Scheme

The protocol uses the CKKS scheme (Cheon–Kim–Kim–Song), a homomorphic
encryption scheme designed for approximate arithmetic on real numbers.
CKKS operates over the polynomial ring

``` math
R = \mathbb{Z}[X] / (X^N + 1), \quad N = 2^{\texttt{log\_n}}
```

where the `log_n` parameter controls the ring dimension. The scheme has
four properties that make it well suited to distributed correlation:

- **SIMD encoding.** A single ciphertext packs up to $`N/2`$ real-valued
  slots. With `log_n = 12` ($`N = 4096`$), each ciphertext holds 2048
  values, so an entire column of observations fits in one ciphertext.
- **Approximate arithmetic.** Additions and multiplications on encrypted
  data introduce small rounding errors, typically on the order of
  $`10^{-4}`$. This is negligible for statistical correlation.
- **Security.** The scheme is based on the Ring Learning With Errors
  (RLWE) problem, which is believed to be hard even for quantum
  computers (post-quantum candidate).
- **Efficient batching.** Element-wise operations on full vectors
  execute in a single homomorphic operation, avoiding per-element
  overhead.

### Threshold Decryption

Rather than entrusting a single party with the secret key, the MHE
protocol uses additive secret sharing. The collective secret key is the
sum of all $`K`$ individual shares:

``` math
sk = sk_1 + sk_2 + \ldots + sk_K
```

No single party holds $`sk`$. Decryption requires **all** $`K`$ parties
to provide their partial decryption shares. Even $`K - 1`$ colluding
parties cannot decrypt any ciphertext without the remaining party’s
cooperation.

### 6-Phase Protocol

The correlation computation proceeds through six phases, each mapped to
a specific server-side function:

| Phase | Operation | Server Function | Description |
|----|----|----|----|
| 1 | Key Generation | `mheInitDS` | Each party generates $`sk_k`$, $`pk_k`$. Party 0 creates the Common Reference Polynomial (CRP). |
| 2 | Key Combination | `mheCombineDS` | Aggregate public key shares into a Collective Public Key (CPK) and Galois keys. |
| 3 | Encryption | `mheEncryptLocalDS` | Z-score columns, encrypt each under the CPK. |
| 4 | Local Correlation | `localCorDS` | Compute plaintext $`\text{cor}(X_k)`$ for within-server blocks. |
| 5 | Cross-Products | `mheCrossProductEncDS` + `mhePartialDecryptDS` | Plaintext $`\times`$ ciphertext multiplication, then threshold decrypt. |
| 6 | Assembly | Client `ds.vertCor` | Fuse all $`K`$ partial shares, divide by $`(n - 1)`$ to obtain $`r_{ij}`$. |

**Phase 1.** Each party $`k`$ independently generates a secret key share
$`sk_k`$. Party 0 additionally generates a Common Reference Polynomial
$`a`$, a uniformly random element of the polynomial ring shared by all
parties. Each party computes its public key share:

``` math
pk_k = (-a \cdot sk_k + e_k, \; a)
```

where $`e_k`$ is a small error polynomial sampled from a discrete
Gaussian distribution. The CRP $`a`$ is distributed so all parties
generate compatible key material.

``` r

result <- ds.vertCor(
  data_name = "D_aligned",
  variables = list(server1 = c("age", "bmi"), server2 = c("glucose")),
  log_n = 12,
  log_scale = 40,
  datasources = connections
)
```

**Phase 2.** The individual public key shares are combined into a
Collective Public Key:

``` math
CPK = \sum_{k=1}^{K} pk_k
```

Data encrypted under the CPK can only be decrypted when all $`K`$
parties cooperate. Galois keys (rotation keys) are similarly aggregated.
No relinearization keys are generated, because the protocol only
requires plaintext $`\times`$ ciphertext multiplication (see below).

**Phase 3.** Each institution $`k`$ standardizes its columns to Z-scores
(mean 0, standard deviation 1) and encrypts each column vector $`z_j`$
under the CPK. The SIMD encoding packs the full $`n`$-length column into
a single ciphertext.

**Phase 4.** Within-server correlations are computed in plaintext since
no data needs to leave the server:

``` math
R_{kk} = \text{cor}(Z_k)
```

No encryption overhead is incurred for these diagonal blocks.

**Phase 5.** For each pair of institutions $`(A, B)`$, institution $`A`$
multiplies its plaintext column $`z_{A,i}`$ by the encrypted column from
institution $`B`$:

``` math
z_{A,i} \cdot \text{Enc}(z_{B,j}) = \text{Enc}(z_{A,i} \odot z_{B,j})
```

The encrypted product is then threshold-decrypted: each party $`k`$
computes a partial decryption share
$`\text{share}_k = -sk_k \cdot ct[1] + e_k'`$ (where $`e_k'`$ is a
smudging noise term). The client fuses all shares:

``` math
m \approx ct[0] + \sum_{k=1}^{K} \text{share}_k
```

**Phase 6.** The client sums the first $`n`$ slots of the recovered
plaintext to obtain the inner product, then divides by $`(n - 1)`$:

``` math
r_{ij} = \frac{\sum_{l=1}^{n} (z_{A,i} \odot z_{B,j})_l}{n - 1}
```

The full correlation matrix is assembled from exact diagonal blocks
(Phase 4) and approximate off-diagonal blocks (Phase 5, with CKKS error
on the order of $`10^{-4}`$).

### Plaintext x Ciphertext Design Choice

A critical design decision is that the homomorphic computation is
limited to **plaintext $`\times`$ ciphertext** multiplication. This has
three consequences:

1.  **Degree stays at 1.** A plaintext-by-ciphertext product keeps the
    ciphertext at degree 1, so no relinearization keys are needed.
2.  **Minimal noise growth.** Without ciphertext-ciphertext
    multiplication, the noise budget is consumed slowly.
3.  **Protocol simplicity.** No evaluation keys, no relinearization
    rounds, no bootstrapping. The only collective key material needed is
    the CPK and Galois keys (for slot rotations in the GLM gradient
    protocol).

This works because institution $`A`$ holds its own data in plaintext and
only the other institution’s data is encrypted. The element-wise product
$`z_{A,i} \cdot \text{Enc}(z_{B,j})`$ is exactly the
plaintext-ciphertext case.

### Security Model

| Entity | Learns | Does NOT Learn |
|----|----|----|
| Server $`k`$ | Own data $`Z_k`$, encrypted columns from others (opaque ciphertexts) | Other servers’ raw data |
| Client | Final correlation matrix $`r_{ij}`$ | Any individual-level data |
| $`K - 1`$ colluding servers | Own data, encrypted intermediates | Remaining server’s data (missing key share masks decryption) |

------------------------------------------------------------------------

## Encrypted-Label BCD-IRLS for GLMs

### Vertical Decomposition

A Generalized Linear Model relates the response $`y`$ to predictors
$`X`$ through $`g(\mu) = \eta = X\beta`$, where $`g(\cdot)`$ is the link
function, $`\mu = E[y]`$, and $`\eta`$ is the linear predictor. With
vertically partitioned data, the linear predictor decomposes:

``` math
\eta = X_1\beta_1 + X_2\beta_2 + \ldots + X_K\beta_K
```

### Key Mathematical Insight

The IRLS update for block $`k`$ is:

``` math
\beta_k^{\text{new}} = (X_k^T W X_k + \lambda I)^{-1} \, X_k^T W (z - \eta_{-k})
```

Decomposing the right-hand side:

``` math
X_k^T W (z - \eta_{-k}) = X_k^T W X_k \, \beta_k + g_k
```

where $`g_k = X_k^T u`$ with $`u = v \odot (y - \mu)`$.

For canonical links (Gaussian, Binomial, Poisson), $`v = 1`$, so
$`u = y - \mu`$.

The key insight is that **only $`g_k = X_k^T u`$ depends on $`y`$**;
everything else ($`\mu`$, $`W`$) is computable from $`\eta`$ alone.
Furthermore, $`g_k`$ has length $`p_k`$ (the number of features on
server $`k`$), **not** length $`n`$ (the number of observations).
Therefore only a $`p_k`$-dimensional gradient needs to be decrypted via
threshold decryption, rather than the full $`n`$-dimensional residual
vector. Since typically $`p_k \ll n`$, this dramatically reduces the
information revealed through decryption.

### Encrypted Protocol

The encrypted-label BCD-IRLS protocol proceeds as follows:

``` r

model <- ds.vertGLM(
  data_name = "D_aligned",
  y_var = "bp",
  x_vars = list(server1 = c("age", "bmi"), server2 = c("glucose"),
                server3 = c("cholesterol", "heart_rate")),
  y_server = "server2",
  family = "gaussian",
  datasources = connections
)
```

1.  The label server encrypts $`y`$ under the CPK, producing $`ct_y`$.
    This ciphertext is distributed to all non-label servers.
2.  $`ct_y`$ is distributed to non-label servers via a chunked transfer
    protocol.
3.  A non-label server $`k`$ computes:
    $`ct_u = ct_y - \text{encode}(\mu)`$, then
    $`g_k[j] = \text{InnerSum}(\text{encode}(x_j) \cdot ct_u)`$ for each
    feature $`j`$. The InnerSum operation uses Galois rotations to sum
    all $`n`$ SIMD slots into a single scalar, collapsing $`n`$
    individual-level products into one aggregate inside the encrypted
    domain.
4.  Threshold decrypt $`g_k`$ (length $`p_k`$). Each of the $`K`$
    servers provides a partial decryption share; the client fuses all
    shares to recover the plaintext gradient.
5.  Server $`k`$ solves:
    $`\beta_k^{\text{new}} = (X_k^T W X_k + \lambda I)^{-1} (X_k^T W X_k \, \beta_k + g_k)`$

The label server uses standard IRLS with plaintext $`y`$; no encryption
is needed for its own block.

### Feature Standardization

Features are automatically standardized (centered and scaled) on each
server before BCD to ensure fast convergence. Without standardization,
correlated features cause slow convergence with contraction rates near
0.98. With standardization, the BCD algorithm converges in 6–12
iterations.

After convergence, coefficients are transformed back to the original
scale:

- **Gaussian family.** Both features and response are standardized.
  $`\beta_{\text{orig}}[j] = \beta_{\text{std}}[j] \times \sigma_y / \sigma_{x_j}`$.
  The intercept is
  $`\beta_0 = \bar{y} - \sum_j \beta_{\text{orig}}[j] \, \bar{x}_j`$.
- **Non-Gaussian families.** Only features are standardized; $`y`$
  remains on the original scale.
  $`\beta_{\text{orig}}[j] = \beta_{\text{std}}[j] / \sigma_{x_j}`$. The
  intercept is recovered from the label server’s IRLS, adjusted for the
  centering:
  $`\beta_0 = \beta_{0,\text{std}} - \sum_j \beta_{\text{orig}}[j] \, \bar{x}_j`$.

### IRLS Family Table

| Family | Link $`g(\mu)`$ | Mean $`\mu(\eta)`$ | Weight $`w`$ | $`v`$ | $`u = v \odot (y - \mu)`$ |
|----|----|----|----|----|----|
| Gaussian | $`\eta`$ | $`\eta`$ | $`1`$ | $`1`$ | $`y - \mu`$ |
| Binomial | $`\log\frac{\mu}{1-\mu}`$ | $`\frac{1}{1+e^{-\eta}}`$ | $`\mu(1-\mu)`$ | $`1`$ | $`y - \mu`$ |
| Poisson | $`\log(\mu)`$ | $`e^{\eta}`$ | $`\mu`$ | $`1`$ | $`y - \mu`$ |

For all three supported families (canonical links), $`v = 1`$. This
simplifies the encrypted computation to $`X_k^T (ct_y - \mu)`$,
eliminating the need to encode and multiply by a separate $`v`$ vector.

### Security Properties

| Entity | Learns | Does NOT Learn |
|----|----|----|
| Client | Final coefficients, deviance, AIC | Individual $`y`$ values, row-level residuals |
| Label server | Own data + $`y`$, $`\eta_{\text{other}}`$ during updates | Other servers’ raw features |
| Non-label server $`k`$ | Own $`X_k`$, $`\mu`$ and $`w`$ (derived from $`\eta`$) | $`y`$ (sees only $`ct_y`$; needs all $`K`$ shares to decrypt) |

### Deviance

Deviance is computed on the label server, which has plaintext $`y`$ and
receives the final total linear predictor $`\eta_{\text{total}}`$.
Standard formulas:

| Family | Deviance |
|----|----|
| Gaussian | $`\sum_i (y_i - \mu_i)^2`$ |
| Binomial | $`2\sum_i \left[ y_i \log\frac{y_i}{\mu_i} + (1 - y_i) \log\frac{1 - y_i}{1 - \mu_i} \right]`$ |
| Poisson | $`2\sum_i \left[ y_i \log\frac{y_i}{\mu_i} - (y_i - \mu_i) \right]`$ |

McFadden’s pseudo $`R^2`$ is then
$`1 - D_{\text{model}} / D_{\text{null}}`$, and the AIC is $`D + 2k`$
where $`k`$ is the number of parameters.

------------------------------------------------------------------------

## Record Alignment

Before any statistical computation, records across servers must be
aligned so that the same row position corresponds to the same
individual. dsVertClient uses an Elliptic-Curve Diffie–Hellman Private
Set Intersection (ECDH-PSI) protocol for privacy-preserving record
linkage.

### ECDH-PSI Protocol

Each server $`k`$ draws a secret scalar $`\alpha_k`$ uniformly at random
from the P-256 curve order and keeps it permanently on the server. The
protocol exploits the **commutativity** of scalar multiplication on
elliptic curves:

``` math
\alpha \cdot (\beta \cdot H(\text{id})) = \beta \cdot (\alpha \cdot H(\text{id}))
```

where $`H(\text{id})`$ maps a patient identifier to a point on the NIST
P-256 curve using hash-to-curve (RFC 9380). The alignment proceeds in
three rounds:

1.  **Mask.** Each server $`k`$ computes $`\alpha_k \cdot H(\text{id})`$
    for every identifier in its local table and sends the resulting
    curve points to the client.
2.  **Double-mask.** The client forwards server $`A`$’s masked points to
    server $`B`$ (and vice versa). Each server applies its own scalar to
    the other server’s points, producing doubly-masked points
    $`\alpha_B \cdot (\alpha_A \cdot H(\text{id}))`$ and
    $`\alpha_A \cdot (\alpha_B \cdot H(\text{id}))`$. By commutativity
    these are equal for the same identifier.
3.  **Intersect and reorder.** The client matches the doubly-masked
    points across servers to find the common identifiers and instructs
    each server to reorder its rows accordingly.

The client sees only opaque elliptic-curve points at every stage and
cannot invert them to recover the original identifiers. Security holds
under the Decisional Diffie–Hellman (DDH) assumption in the semi-honest
model.

``` r

ds.psiAlign("D", "patient_id", "D_aligned", datasources = connections)
```

------------------------------------------------------------------------

## References

- Cheon, J.H., Kim, A., Kim, M. & Song, Y. (2017). “Homomorphic
  Encryption for Arithmetic of Approximate Numbers”. *ASIACRYPT 2017*.
  [doi:10.1007/978-3-319-70694-8_15](https://doi.org/10.1007/978-3-319-70694-8_15)
- Mouchet, C., Troncoso-Pastoriza, J., Bossuat, J.P. & Hubaux, J.P.
  (2021). “Multiparty Homomorphic Encryption from
  Ring-Learning-With-Errors”. *Proceedings on Privacy Enhancing
  Technologies (PETS) 2021*.
  [doi:10.2478/popets-2021-0071](https://doi.org/10.2478/popets-2021-0071)
- van Kesteren, E.J., Hausknecht, D. & Bos, A. (2019).
  “Privacy-Preserving Generalized Linear Models Using Distributed Block
  Coordinate Descent”. *arXiv:1911.03183*.
  [arxiv.org/abs/1911.03183](https://arxiv.org/abs/1911.03183)
- Lattigo v6. Tune Insight SA.
  [github.com/tuneinsight/lattigo](https://github.com/tuneinsight/lattigo)
